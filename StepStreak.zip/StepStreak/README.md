# StepStreak 🔥

Application Android de comptage de pas avec streak, grades et récompenses.
Fonctionne en arrière-plan (service en premier plan) même quand l'app est fermée.

## Fonctionnalités
- Comptage de pas via le capteur `TYPE_STEP_COUNTER` du téléphone
- Service en premier plan + réception au démarrage (`BootReceiver`) pour continuer à compter app fermée
- **Objectif quotidien modifiable** directement depuis l'écran principal (tape sur le chip "Objectif")
- Streak (série de jours consécutifs où l'objectif est atteint)
- Grades : Bronze → Argent → Or → Platine → Diamant → Légende
- Récompenses/badges à 3, 7, 14, 30, 60, 100, 200, 365 jours de streak
- **Nouveau design** : anneau de progression animé, cartes en dégradé, compteur de pas animé
- **Widget d'écran d'accueil** avec anneau de progression, pas du jour et streak, mis à jour en direct
- **Notification enrichie** : barre de progression réelle + message motivant qui évolue selon l'avancement
- **Notifications de célébration** avec son dédié quand l'objectif du jour est atteint ou qu'un badge est débloqué
- **Rappels "envie de marcher ?"** : petite notification + son doux si aucune progression n'est détectée pendant un moment (entre 8h et 22h, désactivable)
- **Réglages** : interrupteurs pour activer/désactiver les sons et les rappels
- Bouton pour désactiver l'optimisation de batterie (essentiel pour la fiabilité du tracking en arrière-plan)

## Compiler l'APK via GitHub

1. Crée un nouveau dépôt GitHub (vide, sans README).
2. Dans ce dossier, ouvre un terminal et exécute :
   ```
   git init
   git add .
   git commit -m "StepStreak - version initiale"
   git branch -M main
   git remote add origin https://github.com/TON-COMPTE/TON-DEPOT.git
   git push -u origin main
   ```
3. Va dans l'onglet **Actions** de ton dépôt GitHub : le workflow "Build APK" se lance automatiquement.
4. Une fois terminé (2-4 minutes), ouvre le run, descends jusqu'à **Artifacts**, télécharge `StepStreak-debug-apk`.
5. Dézippe, transfère le `.apk` sur ton téléphone et installe-le (autorise "sources inconnues" si demandé).

Tu peux aussi relancer une compilation manuellement depuis Actions → Build APK → "Run workflow".

## Important pour la fiabilité en arrière-plan
Android peut tuer les apps en arrière-plan sur certains constructeurs (Xiaomi, Huawei, Samsung, Oppo...).
Après installation :
- Ouvre l'app et appuie sur "Autoriser l'exécution en arrière-plan"
- Sur certains téléphones, va aussi dans Paramètres > Batterie > StepStreak et choisis "Sans restriction" / désactive l'économiseur de batterie pour l'app

## Structure du projet
- `app/src/main/java/com/stepstreak/app/StepService.kt` — service en premier plan, écoute le capteur de pas
- `app/src/main/java/com/stepstreak/app/StepPrefs.kt` — logique de streak, objectifs, badges (SharedPreferences)
- `app/src/main/java/com/stepstreak/app/GradeUtils.kt` — calcul du grade selon le streak
- `app/src/main/java/com/stepstreak/app/MainActivity.kt` — écran principal
- `app/src/main/java/com/stepstreak/app/BootReceiver.kt` — relance le service et les rappels au redémarrage du téléphone
- `app/src/main/java/com/stepstreak/app/CircularStepView.kt` — anneau de progression animé (vue personnalisée)
- `app/src/main/java/com/stepstreak/app/NotificationHelper.kt` — notification de suivi, célébrations, rappels
- `app/src/main/java/com/stepstreak/app/SoundPlayer.kt` — lecture des sons de célébration/rappel
- `app/src/main/java/com/stepstreak/app/ReminderReceiver.kt` / `ReminderScheduler.kt` — rappels "envie de marcher ?"
- `app/src/main/java/com/stepstreak/app/StepWidgetProvider.kt` — widget d'écran d'accueil
- `app/src/main/res/raw/` — sons générés (`chime_success`, `chime_badge`, `chime_nudge`)

## Ajouter le widget à l'écran d'accueil
Une fois l'app installée : appui long sur l'écran d'accueil → Widgets → StepStreak → glisser le widget sur l'écran.
