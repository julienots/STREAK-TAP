# StepStreak 🔥

Application Android de comptage de pas avec streak, grades et récompenses.
Fonctionne en arrière-plan (service en premier plan) même quand l'app est fermée.

## Fonctionnalités
- Comptage de pas via le capteur `TYPE_STEP_COUNTER` du téléphone
- Service en premier plan + réception au démarrage (`BootReceiver`) pour continuer à compter app fermée
- Objectif quotidien de pas (8000 par défaut)
- Streak (série de jours consécutifs où l'objectif est atteint)
- Grades : Bronze → Argent → Or → Platine → Diamant → Légende
- Récompenses/badges à 3, 7, 14, 30, 60, 100, 200, 365 jours de streak
- Bouton pour désactiver l'optimisation de batterie (essentiel pour la fiabilité du tracking en arrière-plan)

## Compiler l'APK via GitHub

1. Crée un nouveau dépôt GitHub (vide, sans README).
2. Dans ce dossier, ouvre un terminal et exécute :
   ```
   git init
   git add .
   git commit -m "StepStreak - version initiale"
   git branch -M main
   git remote add origin https://github.com/TON-COMPTE/TON-DEPOT.git
   git push -u origin main
   ```
3. Va dans l'onglet **Actions** de ton dépôt GitHub : le workflow "Build APK" se lance automatiquement.
4. Une fois terminé (2-4 minutes), ouvre le run, descends jusqu'à **Artifacts**, télécharge `StepStreak-debug-apk`.
5. Dézippe, transfère le `.apk` sur ton téléphone et installe-le (autorise "sources inconnues" si demandé).

Tu peux aussi relancer une compilation manuellement depuis Actions → Build APK → "Run workflow".

## Important pour la fiabilité en arrière-plan
Android peut tuer les apps en arrière-plan sur certains constructeurs (Xiaomi, Huawei, Samsung, Oppo...).
Après installation :
- Ouvre l'app et appuie sur "Autoriser l'exécution en arrière-plan"
- Sur certains téléphones, va aussi dans Paramètres > Batterie > StepStreak et choisis "Sans restriction" / désactive l'économiseur de batterie pour l'app

## Structure du projet
- `app/src/main/java/com/stepstreak/app/StepService.kt` — service en premier plan, écoute le capteur de pas
- `app/src/main/java/com/stepstreak/app/StepPrefs.kt` — logique de streak, objectifs, badges (SharedPreferences)
- `app/src/main/java/com/stepstreak/app/GradeUtils.kt` — calcul du grade selon le streak
- `app/src/main/java/com/stepstreak/app/MainActivity.kt` — écran principal
- `app/src/main/java/com/stepstreak/app/BootReceiver.kt` — relance le service au redémarrage du téléphone
