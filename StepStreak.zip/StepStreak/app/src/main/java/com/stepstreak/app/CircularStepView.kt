package com.stepstreak.app

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.SweepGradient
import android.util.AttributeSet
import android.view.View
import android.view.animation.DecelerateInterpolator
import androidx.core.content.ContextCompat

/**
 * Anneau de progression circulaire animé pour afficher les pas du jour
 * par rapport à l'objectif. Remplace l'ancienne ProgressBar linéaire.
 */
class CircularStepView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {

    private var progress = 0f // 0..1, valeur affichée (animée)
    private var targetProgress = 0f
    private var overflow = false // objectif dépassé -> anneau plein + halo

    private val strokeWidth = dpToPx(16f)

    private val bgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = this@CircularStepView.strokeWidth
        strokeCap = Paint.Cap.ROUND
        color = ContextCompat.getColor(context, R.color.ring_track)
    }

    private val fgPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = this@CircularStepView.strokeWidth
        strokeCap = Paint.Cap.ROUND
    }

    private val rect = RectF()
    private var animator: ValueAnimator? = null

    private val colorStart = ContextCompat.getColor(context, R.color.ring_gradient_start)
    private val colorMid = ContextCompat.getColor(context, R.color.ring_gradient_mid)
    private val colorEnd = ContextCompat.getColor(context, R.color.ring_gradient_end)

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        val inset = strokeWidth / 2f
        rect.set(inset, inset, w - inset, h - inset)
        fgPaint.shader = SweepGradient(
            w / 2f, h / 2f,
            intArrayOf(colorStart, colorMid, colorEnd, colorStart),
            floatArrayOf(0f, 0.5f, 0.9f, 1f)
        )
    }

    /** Définit la progression (0f à 1f+) avec animation fluide depuis la valeur actuelle. */
    fun setProgressAnimated(fraction: Float) {
        val clampedTarget = fraction.coerceIn(0f, 1f)
        overflow = fraction > 1f
        if (clampedTarget == targetProgress) return
        targetProgress = clampedTarget
        animator?.cancel()
        animator = ValueAnimator.ofFloat(progress, clampedTarget).apply {
            duration = 700
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                progress = it.animatedValue as Float
                invalidate()
            }
            start()
        }
    }

    override fun onDraw(canvas: android.graphics.Canvas) {
        super.onDraw(canvas)
        canvas.drawArc(rect, -90f, 360f, false, bgPaint)
        val sweep = 360f * progress
        if (sweep > 0f) {
            canvas.drawArc(rect, -90f, sweep, false, fgPaint)
        }
    }

    private fun dpToPx(dp: Float): Float = dp * resources.displayMetrics.density

    companion object {
        /**
         * Génère un bitmap statique de l'anneau de progression, utilisé par le widget
         * d'écran d'accueil (RemoteViews ne permet pas d'y placer une vue personnalisée).
         */
        fun renderRingBitmap(context: Context, sizePx: Int, progress: Float): android.graphics.Bitmap {
            val bitmap = android.graphics.Bitmap.createBitmap(
                sizePx, sizePx, android.graphics.Bitmap.Config.ARGB_8888
            )
            val canvas = android.graphics.Canvas(bitmap)
            val stroke = sizePx * 0.11f
            val inset = stroke / 2f
            val rect = RectF(inset, inset, sizePx - inset, sizePx - inset)

            val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = stroke
                strokeCap = Paint.Cap.ROUND
                color = ContextCompat.getColor(context, R.color.ring_track)
            }
            val fg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
                style = Paint.Style.STROKE
                strokeWidth = stroke
                strokeCap = Paint.Cap.ROUND
                shader = SweepGradient(
                    sizePx / 2f, sizePx / 2f,
                    intArrayOf(
                        ContextCompat.getColor(context, R.color.ring_gradient_start),
                        ContextCompat.getColor(context, R.color.ring_gradient_mid),
                        ContextCompat.getColor(context, R.color.ring_gradient_end),
                        ContextCompat.getColor(context, R.color.ring_gradient_start)
                    ),
                    floatArrayOf(0f, 0.5f, 0.9f, 1f)
                )
            }

            canvas.drawArc(rect, -90f, 360f, false, bg)
            val clamped = progress.coerceIn(0f, 1f)
            if (clamped > 0f) {
                canvas.drawArc(rect, -90f, 360f * clamped, false, fg)
            }
            return bitmap
        }
    }
}
