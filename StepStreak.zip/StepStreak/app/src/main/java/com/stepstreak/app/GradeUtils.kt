package com.stepstreak.app

object GradeUtils {

    fun gradeForStreak(streak: Int): Pair<String, String> {
        return when {
            streak >= 60 -> "Légende" to "👑"
            streak >= 30 -> "Diamant" to "💎"
            streak >= 14 -> "Platine" to "🏆"
            streak >= 7 -> "Or" to "🥇"
            streak >= 3 -> "Argent" to "🥈"
            else -> "Bronze" to "🥉"
        }
    }

    fun nextGradeThreshold(streak: Int): Int? {
        val thresholds = listOf(3, 7, 14, 30, 60)
        return thresholds.firstOrNull { it > streak }
    }
}
