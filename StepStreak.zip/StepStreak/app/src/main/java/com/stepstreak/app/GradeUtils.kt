package com.stepstreak.app

import android.graphics.Color

object GradeUtils {

    fun gradeForStreak(streak: Int): Pair<String, String> {
        return when {
            streak >= 60 -> "Légende" to "👑"
            streak >= 30 -> "Diamant" to "💎"
            streak >= 14 -> "Platine" to "🏆"
            streak >= 7 -> "Or" to "🥇"
            streak >= 3 -> "Argent" to "🥈"
            else -> "Bronze" to "🥉"
        }
    }

    /** Couleur d'accent associée au grade actuel, utilisée pour le liseré/emoji du bandeau grade. */
    fun gradeAccentColor(streak: Int): Int {
        return when {
            streak >= 60 -> Color.parseColor("#FF7A45") // Légende
            streak >= 30 -> Color.parseColor("#7DD3FC") // Diamant
            streak >= 14 -> Color.parseColor("#E5E4E2") // Platine
            streak >= 7 -> Color.parseColor("#FFD54F")  // Or
            streak >= 3 -> Color.parseColor("#C7CBD1")  // Argent
            else -> Color.parseColor("#CD7F32")         // Bronze
        }
    }

    fun nextGradeThreshold(streak: Int): Int? {
        val thresholds = listOf(3, 7, 14, 30, 60)
        return thresholds.firstOrNull { it > streak }
    }
}
