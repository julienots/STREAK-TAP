package com.stepstreak.app

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private lateinit var tvSteps: TextView
    private lateinit var tvGoal: TextView
    private lateinit var progressBar: ProgressBar
    private lateinit var tvStreak: TextView
    private lateinit var tvGrade: TextView
    private lateinit var tvGradeEmoji: TextView
    private lateinit var tvNextGrade: TextView
    private lateinit var badgesContainer: LinearLayout

    private val stepsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshUI()
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> startTracking() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvSteps = findViewById(R.id.tvSteps)
        tvGoal = findViewById(R.id.tvGoal)
        progressBar = findViewById(R.id.progressBar)
        tvStreak = findViewById(R.id.tvStreak)
        tvGrade = findViewById(R.id.tvGrade)
        tvGradeEmoji = findViewById(R.id.tvGradeEmoji)
        tvNextGrade = findViewById(R.id.tvNextGrade)
        badgesContainer = findViewById(R.id.badgesContainer)

        findViewById<Button>(R.id.btnBattery).setOnClickListener { requestIgnoreBatteryOptimizations() }

        requestNeededPermissions()
    }

    override fun onResume() {
        super.onResume()
        StepPrefs.checkMissedStreak(this)
        val filter = IntentFilter(StepService.ACTION_STEPS_UPDATED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(stepsReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(stepsReceiver, filter)
        }
        refreshUI()
    }

    override fun onPause() {
        super.onPause()
        try {
            unregisterReceiver(stepsReceiver)
        } catch (e: Exception) {
            // déjà désinscrit
        }
    }

    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            needed.add(Manifest.permission.ACTIVITY_RECOGNITION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val toRequest = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (toRequest.isNotEmpty()) {
            permissionLauncher.launch(toRequest.toTypedArray())
        } else {
            startTracking()
        }
    }

    private fun startTracking() {
        StepService.start(this)
        refreshUI()
    }

    private fun requestIgnoreBatteryOptimizations() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        } else {
            Toast.makeText(this, "Déjà autorisé ✅", Toast.LENGTH_SHORT).show()
        }
    }

    private fun refreshUI() {
        val steps = StepPrefs.getTodaySteps(this)
        val goal = StepPrefs.dailyGoal(this)
        val streak = StepPrefs.getStreak(this)
        val longest = StepPrefs.getLongestStreak(this)
        val (gradeName, gradeEmoji) = GradeUtils.gradeForStreak(streak)
        val next = GradeUtils.nextGradeThreshold(streak)

        tvSteps.text = steps.toString()
        tvGoal.text = getString(R.string.goal_format, goal)
        progressBar.max = goal
        progressBar.progress = steps.coerceAtMost(goal)
        tvStreak.text = getString(R.string.streak_format, streak, longest)
        tvGrade.text = gradeName
        tvGradeEmoji.text = gradeEmoji
        tvNextGrade.text = if (next != null)
            getString(R.string.next_grade_format, next - streak)
        else
            getString(R.string.max_grade)

        renderBadges(streak)
    }

    private fun renderBadges(streak: Int) {
        badgesContainer.removeAllViews()
        val unlocked = StepPrefs.getUnlockedBadges(this)
        StepPrefs.allMilestones.forEach { milestone ->
            val isUnlocked = unlocked.contains(milestone.toString()) || streak >= milestone
            val tv = TextView(this)
            tv.text = (if (isUnlocked) "🏅 " else "🔒 ") + getString(R.string.badge_days, milestone)
            tv.setTextColor(
                ContextCompat.getColor(this, if (isUnlocked) R.color.gold else R.color.gray)
            )
            tv.textSize = 15f
            tv.setPadding(0, 12, 0, 12)
            badgesContainer.addView(tv)
        }
    }
}
