package com.stepstreak.app

import android.Manifest
import android.animation.ValueAnimator
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.text.InputType
import android.view.animation.DecelerateInterpolator
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.ContextCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {

    private lateinit var ringView: CircularStepView
    private lateinit var tvSteps: TextView
    private lateinit var tvGoal: TextView
    private lateinit var tvMotivation: TextView
    private lateinit var tvDate: TextView
    private lateinit var tvStreak: TextView
    private lateinit var tvGrade: TextView
    private lateinit var tvGradeEmoji: TextView
    private lateinit var tvNextGrade: TextView
    private lateinit var badgesContainer: LinearLayout
    private lateinit var goalRow: LinearLayout
    private lateinit var switchSounds: SwitchCompat
    private lateinit var switchReminders: SwitchCompat

    private var displayedSteps = 0

    private val stepsReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            refreshUI()
        }
    }

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> startTracking() }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        ringView = findViewById(R.id.ringView)
        tvSteps = findViewById(R.id.tvSteps)
        tvGoal = findViewById(R.id.tvGoal)
        tvMotivation = findViewById(R.id.tvMotivation)
        tvDate = findViewById(R.id.tvDate)
        tvStreak = findViewById(R.id.tvStreak)
        tvGrade = findViewById(R.id.tvGrade)
        tvGradeEmoji = findViewById(R.id.tvGradeEmoji)
        tvNextGrade = findViewById(R.id.tvNextGrade)
        badgesContainer = findViewById(R.id.badgesContainer)
        goalRow = findViewById(R.id.goalRow)
        switchSounds = findViewById(R.id.switchSounds)
        switchReminders = findViewById(R.id.switchReminders)

        val sdf = SimpleDateFormat("EEEE d MMMM", Locale.FRENCH)
        tvDate.text = sdf.format(Date()).replaceFirstChar { it.uppercase() }

        findViewById<Button>(R.id.btnBattery).setOnClickListener { requestIgnoreBatteryOptimizations() }
        goalRow.setOnClickListener { showEditGoalDialog() }

        switchSounds.setOnCheckedChangeListener { _, checked ->
            StepPrefs.setSoundsEnabled(this, checked)
        }
        switchReminders.setOnCheckedChangeListener { _, checked ->
            StepPrefs.setRemindersEnabled(this, checked)
            if (checked) ReminderScheduler.scheduleNext(this) else ReminderScheduler.cancel(this)
        }

        requestNeededPermissions()
    }

    override fun onResume() {
        super.onResume()
        StepPrefs.checkMissedStreak(this)
        val filter = IntentFilter(StepService.ACTION_STEPS_UPDATED)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(stepsReceiver, filter, Context.RECEIVER_NOT_EXPORTED)
        } else {
            @Suppress("UnspecifiedRegisterReceiverFlag")
            registerReceiver(stepsReceiver, filter)
        }
        switchSounds.isChecked = StepPrefs.soundsEnabled(this)
        switchReminders.isChecked = StepPrefs.remindersEnabled(this)
        refreshUI()
        StepWidgetProvider.updateAll(this)
    }

    override fun onPause() {
        super.onPause()
        try {
            unregisterReceiver(stepsReceiver)
        } catch (e: Exception) {
            // déjà désinscrit
        }
    }

    private fun requestNeededPermissions() {
        val needed = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            needed.add(Manifest.permission.ACTIVITY_RECOGNITION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            needed.add(Manifest.permission.POST_NOTIFICATIONS)
        }
        val toRequest = needed.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }
        if (toRequest.isNotEmpty()) {
            permissionLauncher.launch(toRequest.toTypedArray())
        } else {
            startTracking()
        }
    }

    private fun startTracking() {
        StepService.start(this)
        ReminderScheduler.scheduleNext(this)
        refreshUI()
    }

    private fun requestIgnoreBatteryOptimizations() {
        val pm = getSystemService(Context.POWER_SERVICE) as PowerManager
        if (!pm.isIgnoringBatteryOptimizations(packageName)) {
            val intent = Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS)
            intent.data = Uri.parse("package:$packageName")
            startActivity(intent)
        } else {
            Toast.makeText(this, "Déjà autorisé ✅", Toast.LENGTH_SHORT).show()
        }
    }

    private fun showEditGoalDialog() {
        val currentGoal = StepPrefs.dailyGoal(this)
        val input = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(currentGoal.toString())
            setSelection(text.length)
            setPadding(48, 32, 48, 32)
        }
        AlertDialog.Builder(this)
            .setTitle("Objectif quotidien")
            .setMessage("Combien de pas veux-tu viser chaque jour ?")
            .setView(input)
            .setPositiveButton("Enregistrer") { _, _ ->
                val value = input.text.toString().toIntOrNull()
                if (value != null && value > 0) {
                    StepPrefs.setDailyGoal(this, value)
                    refreshUI()
                    StepWidgetProvider.updateAll(this)
                } else {
                    Toast.makeText(this, "Entre un nombre valide", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Annuler", null)
            .show()
    }

    private fun refreshUI() {
        val steps = StepPrefs.getTodaySteps(this)
        val goal = StepPrefs.dailyGoal(this)
        val streak = StepPrefs.getStreak(this)
        val longest = StepPrefs.getLongestStreak(this)
        val (gradeName, gradeEmoji) = GradeUtils.gradeForStreak(streak)
        val next = GradeUtils.nextGradeThreshold(streak)

        animateStepsCount(steps)
        ringView.setProgressAnimated(if (goal > 0) steps.toFloat() / goal else 0f)

        tvGoal.text = getString(R.string.goal_format, goal)
        tvStreak.text = getString(R.string.streak_format, streak, longest)
        tvGrade.text = gradeName
        tvGradeEmoji.text = gradeEmoji
        tvNextGrade.text = if (next != null)
            getString(R.string.next_grade_format, next - streak)
        else
            getString(R.string.max_grade)
        tvMotivation.text = motivationFor(steps, goal, streak)

        renderBadges(streak)
    }

    private fun motivationFor(steps: Int, goal: Int, streak: Int): String {
        if (goal <= 0) return ""
        val ratio = steps.toFloat() / goal
        return when {
            ratio >= 1f -> "Objectif du jour atteint, bravo ! 🎉"
            ratio >= 0.75f -> "Encore ${goal - steps} pas et c'est gagné 💪"
            ratio >= 0.4f -> "Bon rythme, continue comme ça !"
            steps == 0 -> "Envie de marcher ? C'est le moment idéal 🚶"
            else -> "Chaque pas compte, en route !"
        }
    }

    private fun animateStepsCount(target: Int) {
        val start = displayedSteps
        if (start == target) {
            tvSteps.text = target.toString()
            return
        }
        ValueAnimator.ofInt(start, target).apply {
            duration = 600
            interpolator = DecelerateInterpolator()
            addUpdateListener {
                val value = it.animatedValue as Int
                tvSteps.text = value.toString()
            }
            start()
        }
        displayedSteps = target
    }

    private fun renderBadges(streak: Int) {
        badgesContainer.removeAllViews()
        val unlocked = StepPrefs.getUnlockedBadges(this)
        val density = resources.displayMetrics.density
        StepPrefs.allMilestones.forEach { milestone ->
            val isUnlocked = unlocked.contains(milestone.toString()) || streak >= milestone
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                setBackgroundResource(if (isUnlocked) R.drawable.bg_badge_unlocked else R.drawable.bg_badge_locked)
                setPadding((16 * density).toInt(), (14 * density).toInt(), (16 * density).toInt(), (14 * density).toInt())
                val lp = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                lp.bottomMargin = (10 * density).toInt()
                layoutParams = lp
                gravity = android.view.Gravity.CENTER_VERTICAL
            }
            val emoji = TextView(this).apply {
                text = if (isUnlocked) "🏅" else "🔒"
                textSize = 20f
                setPadding(0, 0, (14 * density).toInt(), 0)
            }
            val label = TextView(this).apply {
                text = getString(R.string.badge_days, milestone)
                setTextColor(
                    ContextCompat.getColor(
                        this@MainActivity,
                        if (isUnlocked) R.color.text_primary else R.color.text_faint
                    )
                )
                textSize = 15f
            }
            row.addView(emoji)
            row.addView(label)
            badgesContainer.addView(row)
        }
    }
}
