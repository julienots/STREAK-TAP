package com.stepstreak.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import androidx.core.app.NotificationCompat

/**
 * Centralise la création des notifications de l'app :
 * - suivi en continu (barre de progression + message motivant)
 * - célébration (objectif du jour atteint / badge débloqué)
 * - rappel "envie de marcher" quand aucune activité n'est détectée
 */
object NotificationHelper {

    const val CHANNEL_TRACKING = "step_streak_tracking"
    const val CHANNEL_CELEBRATION = "step_streak_celebration"
    const val CHANNEL_REMINDER = "step_streak_reminder"

    const val NOTIF_TRACKING_ID = 1001
    const val NOTIF_CELEBRATION_ID = 1002
    const val NOTIF_REMINDER_ID = 1003

    fun ensureChannels(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val nm = context.getSystemService(NotificationManager::class.java)

        val tracking = NotificationChannel(
            CHANNEL_TRACKING, "Suivi des pas", NotificationManager.IMPORTANCE_LOW
        ).apply {
            description = "Notification permanente affichant ta progression du jour"
            setShowBadge(false)
        }

        val celebrationSound = Uri.parse(
            "android.resource://${context.packageName}/${R.raw.chime_success}"
        )
        val celebration = NotificationChannel(
            CHANNEL_CELEBRATION, "Récompenses & objectifs atteints", NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Alertes quand tu atteins ton objectif ou débloques un badge"
            enableVibration(true)
            setSound(celebrationSound, android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION_EVENT)
                .build())
        }

        val nudgeSound = Uri.parse(
            "android.resource://${context.packageName}/${R.raw.chime_nudge}"
        )
        val reminder = NotificationChannel(
            CHANNEL_REMINDER, "Envie de marcher ?", NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = "Petits rappels si tu n'as pas bougé depuis un moment"
            enableVibration(true)
            setSound(nudgeSound, android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_NOTIFICATION_EVENT)
                .build())
        }

        nm.createNotificationChannel(tracking)
        nm.createNotificationChannel(celebration)
        nm.createNotificationChannel(reminder)
    }

    private fun openAppIntent(context: Context): PendingIntent {
        val intent = Intent(context, MainActivity::class.java)
        return PendingIntent.getActivity(
            context, 0, intent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
    }

    /** Notification permanente du service : pas du jour, objectif, message motivant, streak. */
    fun buildTrackingNotification(context: Context, steps: Int): Notification {
        val goal = StepPrefs.dailyGoal(context)
        val streak = StepPrefs.getStreak(context)
        val percent = if (goal > 0) ((steps.toFloat() / goal) * 100).toInt().coerceIn(0, 100) else 0
        val motivation = motivationalMessage(steps, goal, streak)

        val builder = NotificationCompat.Builder(context, CHANNEL_TRACKING)
            .setContentTitle("$steps / $goal pas • $percent%")
            .setContentText(motivation)
            .setSmallIcon(R.drawable.ic_stat_walk)
            .setContentIntent(openAppIntent(context))
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setProgress(goal.coerceAtLeast(1), steps.coerceAtMost(goal), false)
            .setStyle(NotificationCompat.BigTextStyle().bigText(motivation))

        if (streak > 0) {
            builder.setSubText("🔥 Série de $streak jour${if (streak > 1) "s" else ""}")
        }

        return builder.build()
    }

    fun updateTrackingNotification(context: Context, steps: Int) {
        ensureChannels(context)
        val nm = context.getSystemService(NotificationManager::class.java)
        nm.notify(NOTIF_TRACKING_ID, buildTrackingNotification(context, steps))
    }

    private fun motivationalMessage(steps: Int, goal: Int, streak: Int): String {
        if (goal <= 0) return "Continue comme ça !"
        val ratio = steps.toFloat() / goal
        return when {
            ratio >= 1f -> "Objectif atteint aujourd'hui, bravo ! 🎉"
            ratio >= 0.75f -> "Presque là, encore ${(goal - steps)} pas ! 💪"
            ratio >= 0.5f -> "Tu es à mi-chemin, continue !"
            ratio >= 0.25f -> "Bon début, garde le rythme 🚶"
            steps == 0 && streak > 0 -> "Ta série de $streak jours t'attend, en route !"
            else -> "C'est parti pour une nouvelle journée active."
        }
    }

    /** Notification de célébration : objectif du jour atteint. */
    fun showGoalReachedNotification(context: Context, steps: Int) {
        ensureChannels(context)
        val notif = NotificationCompat.Builder(context, CHANNEL_CELEBRATION)
            .setContentTitle("Objectif atteint aujourd'hui ! 🎉")
            .setContentText("$steps pas parcourus, tu assures !")
            .setSmallIcon(R.drawable.ic_stat_walk)
            .setContentIntent(openAppIntent(context))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        context.getSystemService(NotificationManager::class.java)
            .notify(NOTIF_CELEBRATION_ID, notif)
    }

    /** Notification de célébration : nouveau badge / grade débloqué. */
    fun showBadgeUnlockedNotification(context: Context, milestone: Int) {
        ensureChannels(context)
        val streak = StepPrefs.getStreak(context)
        val (gradeName, gradeEmoji) = GradeUtils.gradeForStreak(streak)
        val notif = NotificationCompat.Builder(context, CHANNEL_CELEBRATION)
            .setContentTitle("$gradeEmoji Nouveau badge débloqué !")
            .setContentText("$milestone jours de suite — grade $gradeName")
            .setSmallIcon(R.drawable.ic_stat_walk)
            .setContentIntent(openAppIntent(context))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        context.getSystemService(NotificationManager::class.java)
            .notify(NOTIF_CELEBRATION_ID + milestone, notif)
    }

    /** Rappel "envie de marcher ?" quand aucun pas n'a été détecté depuis un moment. */
    fun showWalkReminderNotification(context: Context) {
        if (!StepPrefs.remindersEnabled(context)) return
        ensureChannels(context)
        val messages = listOf(
            "Une petite pause marche te ferait du bien 🚶",
            "Envie de bouger un peu ? Quelques pas t'attendent.",
            "Ton objectif du jour a besoin de toi, en route !",
            "Debout ! Même 5 minutes de marche comptent."
        )
        val text = messages.random()
        val notif = NotificationCompat.Builder(context, CHANNEL_REMINDER)
            .setContentTitle("Envie de marcher ? 👟")
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_stat_walk)
            .setContentIntent(openAppIntent(context))
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_DEFAULT)
            .build()
        context.getSystemService(NotificationManager::class.java)
            .notify(NOTIF_REMINDER_ID, notif)
        SoundPlayer.playNudge(context)
    }
}
