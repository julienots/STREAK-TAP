package com.stepstreak.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import java.util.Calendar

/**
 * Reçoit les alarmes périodiques et déclenche une notification "envie de marcher ?"
 * si l'utilisateur n'a pas progressé depuis un moment, pendant les heures de la journée.
 */
class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (!StepPrefs.remindersEnabled(context)) return

        val hour = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        if (hour < QUIET_HOURS_END || hour >= QUIET_HOURS_START) return // pas de rappel la nuit

        val goalAlreadyReached = StepPrefs.getTodaySteps(context) >= StepPrefs.dailyGoal(context)
        if (goalAlreadyReached) return

        val stagnant = StepPrefs.stepsStagnantSinceLastCheck(context)
        val inactiveLongEnough = StepPrefs.minutesSinceLastActivity(context) >= MIN_INACTIVE_MINUTES

        if (stagnant && inactiveLongEnough) {
            NotificationHelper.showWalkReminderNotification(context)
        }

        ReminderScheduler.scheduleNext(context)
    }

    companion object {
        private const val QUIET_HOURS_START = 22 // pas de rappel après 22h
        private const val QUIET_HOURS_END = 8    // ni avant 8h
        private const val MIN_INACTIVE_MINUTES = 90
    }
}
