package com.stepstreak.app

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer

/**
 * Petite fabrique de sons pour les moments clés de l'app :
 * objectif du jour atteint, badge/grade débloqué, rappel "envie de marcher".
 * Respecte le réglage utilisateur StepPrefs.soundsEnabled().
 */
object SoundPlayer {

    fun playGoalReached(context: Context) = play(context, R.raw.chime_success)

    fun playBadgeUnlocked(context: Context) = play(context, R.raw.chime_badge)

    fun playNudge(context: Context) = play(context, R.raw.chime_nudge)

    private fun play(context: Context, resId: Int) {
        if (!StepPrefs.soundsEnabled(context)) return
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            val afd = context.resources.openRawResourceFd(resId)
            mp.setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
            afd.close()
            mp.setOnCompletionListener { it.release() }
            mp.setOnErrorListener { player, _, _ -> player.release(); true }
            mp.prepare()
            mp.start()
        } catch (e: Exception) {
            // Lecture du son best-effort : on ignore silencieusement les échecs
        }
    }
}
