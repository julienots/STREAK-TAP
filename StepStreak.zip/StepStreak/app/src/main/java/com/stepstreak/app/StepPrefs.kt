package com.stepstreak.app

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object StepPrefs {
    private const val PREFS = "step_streak_prefs"
    private const val KEY_BASELINE = "baseline"
    private const val KEY_BASELINE_DATE = "baseline_date"
    private const val KEY_TODAY_STEPS = "today_steps"
    private const val KEY_TOTAL_STEPS = "total_steps"
    private const val KEY_STREAK = "streak"
    private const val KEY_LONGEST_STREAK = "longest_streak"
    private const val KEY_LAST_COUNTED_DATE = "last_counted_date"
    private const val KEY_DAILY_GOAL = "daily_goal"
    private const val KEY_BADGES = "unlocked_badges"

    private val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    val allMilestones = listOf(3, 7, 14, 30, 60, 100, 200, 365)

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun todayKey(): String = sdf.format(Date())

    fun dailyGoal(context: Context): Int = prefs(context).getInt(KEY_DAILY_GOAL, 8000)

    fun setDailyGoal(context: Context, goal: Int) {
        prefs(context).edit().putInt(KEY_DAILY_GOAL, goal).apply()
    }

    /** Appelé à chaque lecture du capteur (valeur cumulée depuis le dernier redémarrage). */
    fun onSensorReading(context: Context, sensorTotal: Int) {
        val p = prefs(context)
        val today = todayKey()
        val baselineDate = p.getString(KEY_BASELINE_DATE, null)

        if (baselineDate != today) {
            if (baselineDate != null) {
                val yesterdaySteps = p.getInt(KEY_TODAY_STEPS, 0)
                p.edit().putInt(KEY_TOTAL_STEPS, p.getInt(KEY_TOTAL_STEPS, 0) + yesterdaySteps).apply()
                evaluateStreakForDay(context, baselineDate, yesterdaySteps)
            }
            p.edit()
                .putString(KEY_BASELINE_DATE, today)
                .putInt(KEY_BASELINE, sensorTotal)
                .putInt(KEY_TODAY_STEPS, 0)
                .apply()
        } else {
            val baseline = p.getInt(KEY_BASELINE, sensorTotal)
            var steps = sensorTotal - baseline
            if (steps < 0) steps = 0 // le téléphone a redémarré, le capteur est reparti à 0
            p.edit().putInt(KEY_TODAY_STEPS, steps).apply()
            checkGoalReachedToday(context, steps)
        }
    }

    private fun checkGoalReachedToday(context: Context, steps: Int) {
        val p = prefs(context)
        val today = todayKey()
        if (steps >= dailyGoal(context) && p.getString(KEY_LAST_COUNTED_DATE, "") != today) {
            incrementStreak(context, today)
        }
    }

    private fun evaluateStreakForDay(context: Context, date: String, steps: Int) {
        val p = prefs(context)
        if (steps >= dailyGoal(context) && p.getString(KEY_LAST_COUNTED_DATE, "") != date) {
            incrementStreak(context, date)
        }
    }

    private fun incrementStreak(context: Context, countedDate: String) {
        val p = prefs(context)
        val lastCounted = p.getString(KEY_LAST_COUNTED_DATE, null)
        val newStreak = when {
            lastCounted == countedDate -> p.getInt(KEY_STREAK, 0)
            lastCounted != null && isYesterday(lastCounted, countedDate) -> p.getInt(KEY_STREAK, 0) + 1
            else -> 1
        }
        val longest = maxOf(newStreak, p.getInt(KEY_LONGEST_STREAK, 0))
        p.edit()
            .putInt(KEY_STREAK, newStreak)
            .putInt(KEY_LONGEST_STREAK, longest)
            .putString(KEY_LAST_COUNTED_DATE, countedDate)
            .apply()
        checkBadgeUnlocks(context, newStreak)
    }

    /** À appeler à chaque ouverture de l'app : casse le streak si un jour a été manqué. */
    fun checkMissedStreak(context: Context) {
        val p = prefs(context)
        val lastCounted = p.getString(KEY_LAST_COUNTED_DATE, null) ?: return
        val today = todayKey()
        if (lastCounted != today && !isYesterday(lastCounted, today)) {
            p.edit().putInt(KEY_STREAK, 0).apply()
        }
    }

    private fun isYesterday(dateStr: String, referenceToday: String): Boolean {
        return try {
            val cal = Calendar.getInstance()
            cal.time = sdf.parse(referenceToday)!!
            cal.add(Calendar.DAY_OF_YEAR, -1)
            sdf.format(cal.time) == dateStr
        } catch (e: Exception) {
            false
        }
    }

    fun getTodaySteps(context: Context): Int = prefs(context).getInt(KEY_TODAY_STEPS, 0)
    fun getTotalSteps(context: Context): Int = prefs(context).getInt(KEY_TOTAL_STEPS, 0) + getTodaySteps(context)
    fun getStreak(context: Context): Int = prefs(context).getInt(KEY_STREAK, 0)
    fun getLongestStreak(context: Context): Int = prefs(context).getInt(KEY_LONGEST_STREAK, 0)

    fun getUnlockedBadges(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_BADGES, emptySet()) ?: emptySet()

    private fun checkBadgeUnlocks(context: Context, streak: Int) {
        val p = prefs(context)
        val current = (p.getStringSet(KEY_BADGES, emptySet()) ?: emptySet()).toMutableSet()
        allMilestones.forEach { m -> if (streak >= m) current.add(m.toString()) }
        p.edit().putStringSet(KEY_BADGES, current).apply()
    }
}
