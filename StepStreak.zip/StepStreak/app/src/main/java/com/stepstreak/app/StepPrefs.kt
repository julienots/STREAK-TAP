package com.stepstreak.app

import android.content.Context
import android.content.SharedPreferences
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object StepPrefs {
    private const val PREFS = "step_streak_prefs"
    private const val KEY_BASELINE = "baseline"
    private const val KEY_BASELINE_DATE = "baseline_date"
    private const val KEY_TODAY_STEPS = "today_steps"
    private const val KEY_TOTAL_STEPS = "total_steps"
    private const val KEY_STREAK = "streak"
    private const val KEY_LONGEST_STREAK = "longest_streak"
    private const val KEY_LAST_COUNTED_DATE = "last_counted_date"
    private const val KEY_DAILY_GOAL = "daily_goal"
    private const val KEY_BADGES = "unlocked_badges"
    private const val KEY_CELEBRATED_GOAL_DATE = "celebrated_goal_date"
    private const val KEY_LAST_ACTIVITY_TS = "last_activity_ts"
    private const val KEY_LAST_STEPS_AT_ACTIVITY_CHECK = "last_steps_at_activity_check"
    private const val KEY_SOUNDS_ENABLED = "sounds_enabled"
    private const val KEY_REMINDERS_ENABLED = "reminders_enabled"

    private val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    val allMilestones = listOf(3, 7, 14, 30, 60, 100, 200, 365)

    private fun prefs(context: Context): SharedPreferences =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun todayKey(): String = sdf.format(Date())

    fun dailyGoal(context: Context): Int = prefs(context).getInt(KEY_DAILY_GOAL, 8000)

    fun setDailyGoal(context: Context, goal: Int) {
        prefs(context).edit().putInt(KEY_DAILY_GOAL, goal.coerceIn(1000, 50000)).apply()
    }

    fun soundsEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_SOUNDS_ENABLED, true)
    fun setSoundsEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_SOUNDS_ENABLED, enabled).apply()
    }

    fun remindersEnabled(context: Context): Boolean = prefs(context).getBoolean(KEY_REMINDERS_ENABLED, true)
    fun setRemindersEnabled(context: Context, enabled: Boolean) {
        prefs(context).edit().putBoolean(KEY_REMINDERS_ENABLED, enabled).apply()
    }

    /** Résultat d'une lecture du capteur : ce qui doit être célébré (son + notif), le cas échéant. */
    data class SensorResult(
        val todaySteps: Int,
        val goalJustReached: Boolean,
        val newlyUnlockedBadge: Int?
    )

    /** Appelé à chaque lecture du capteur (valeur cumulée depuis le dernier redémarrage). */
    fun onSensorReading(context: Context, sensorTotal: Int): SensorResult {
        val p = prefs(context)
        val today = todayKey()
        val baselineDate = p.getString(KEY_BASELINE_DATE, null)

        if (baselineDate != today) {
            if (baselineDate != null) {
                val yesterdaySteps = p.getInt(KEY_TODAY_STEPS, 0)
                p.edit().putInt(KEY_TOTAL_STEPS, p.getInt(KEY_TOTAL_STEPS, 0) + yesterdaySteps).apply()
                evaluateStreakForDay(context, baselineDate, yesterdaySteps)
            }
            p.edit()
                .putString(KEY_BASELINE_DATE, today)
                .putInt(KEY_BASELINE, sensorTotal)
                .putInt(KEY_TODAY_STEPS, 0)
                .putLong(KEY_LAST_ACTIVITY_TS, System.currentTimeMillis())
                .putInt(KEY_LAST_STEPS_AT_ACTIVITY_CHECK, -1)
                .apply()
            return SensorResult(0, false, null)
        } else {
            val baseline = p.getInt(KEY_BASELINE, sensorTotal)
            var steps = sensorTotal - baseline
            if (steps < 0) steps = 0 // le téléphone a redémarré, le capteur est reparti à 0
            p.edit().putInt(KEY_TODAY_STEPS, steps).apply()
            if (steps > 0) {
                p.edit().putLong(KEY_LAST_ACTIVITY_TS, System.currentTimeMillis()).apply()
            }
            return checkGoalReachedToday(context, steps)
        }
    }

    private fun checkGoalReachedToday(context: Context, steps: Int): SensorResult {
        val p = prefs(context)
        val today = todayKey()
        var goalJustReached = false
        var newBadge: Int? = null
        if (steps >= dailyGoal(context) && p.getString(KEY_LAST_COUNTED_DATE, "") != today) {
            newBadge = incrementStreak(context, today)
        }
        if (steps >= dailyGoal(context) && p.getString(KEY_CELEBRATED_GOAL_DATE, "") != today) {
            p.edit().putString(KEY_CELEBRATED_GOAL_DATE, today).apply()
            goalJustReached = true
        }
        return SensorResult(steps, goalJustReached, newBadge)
    }

    private fun evaluateStreakForDay(context: Context, date: String, steps: Int) {
        val p = prefs(context)
        if (steps >= dailyGoal(context) && p.getString(KEY_LAST_COUNTED_DATE, "") != date) {
            incrementStreak(context, date)
        }
    }

    /** Incrémente le streak et retourne le palier de badge tout juste débloqué (ou null). */
    private fun incrementStreak(context: Context, countedDate: String): Int? {
        val p = prefs(context)
        val lastCounted = p.getString(KEY_LAST_COUNTED_DATE, null)
        val newStreak = when {
            lastCounted == countedDate -> p.getInt(KEY_STREAK, 0)
            lastCounted != null && isYesterday(lastCounted, countedDate) -> p.getInt(KEY_STREAK, 0) + 1
            else -> 1
        }
        val longest = maxOf(newStreak, p.getInt(KEY_LONGEST_STREAK, 0))
        p.edit()
            .putInt(KEY_STREAK, newStreak)
            .putInt(KEY_LONGEST_STREAK, longest)
            .putString(KEY_LAST_COUNTED_DATE, countedDate)
            .apply()
        return checkBadgeUnlocks(context, newStreak)
    }

    /** À appeler à chaque ouverture de l'app : casse le streak si un jour a été manqué. */
    fun checkMissedStreak(context: Context) {
        val p = prefs(context)
        val lastCounted = p.getString(KEY_LAST_COUNTED_DATE, null) ?: return
        val today = todayKey()
        if (lastCounted != today && !isYesterday(lastCounted, today)) {
            p.edit().putInt(KEY_STREAK, 0).apply()
        }
    }

    private fun isYesterday(dateStr: String, referenceToday: String): Boolean {
        return try {
            val cal = Calendar.getInstance()
            cal.time = sdf.parse(referenceToday)!!
            cal.add(Calendar.DAY_OF_YEAR, -1)
            sdf.format(cal.time) == dateStr
        } catch (e: Exception) {
            false
        }
    }

    fun getTodaySteps(context: Context): Int = prefs(context).getInt(KEY_TODAY_STEPS, 0)
    fun getTotalSteps(context: Context): Int = prefs(context).getInt(KEY_TOTAL_STEPS, 0) + getTodaySteps(context)
    fun getStreak(context: Context): Int = prefs(context).getInt(KEY_STREAK, 0)
    fun getLongestStreak(context: Context): Int = prefs(context).getInt(KEY_LONGEST_STREAK, 0)
    fun hasCelebratedGoalToday(context: Context): Boolean =
        prefs(context).getString(KEY_CELEBRATED_GOAL_DATE, "") == todayKey()

    fun getUnlockedBadges(context: Context): Set<String> =
        prefs(context).getStringSet(KEY_BADGES, emptySet()) ?: emptySet()

    private fun checkBadgeUnlocks(context: Context, streak: Int): Int? {
        val p = prefs(context)
        val current = (p.getStringSet(KEY_BADGES, emptySet()) ?: emptySet()).toMutableSet()
        var newlyUnlocked: Int? = null
        allMilestones.forEach { m ->
            if (streak >= m && !current.contains(m.toString())) {
                current.add(m.toString())
                newlyUnlocked = m
            }
        }
        p.edit().putStringSet(KEY_BADGES, current).apply()
        return newlyUnlocked
    }

    // --- Suivi d'inactivité pour les rappels "envie de marcher" ---

    /** Nombre de minutes depuis la dernière progression de pas détectée (ou depuis minuit si aucune donnée). */
    fun minutesSinceLastActivity(context: Context): Long {
        val last = prefs(context).getLong(KEY_LAST_ACTIVITY_TS, 0L)
        if (last == 0L) return 0L
        return (System.currentTimeMillis() - last) / 60000L
    }

    /** Retourne true si le nombre de pas n'a pas progressé depuis la dernière vérification (pour le rappel). */
    fun stepsStagnantSinceLastCheck(context: Context): Boolean {
        val p = prefs(context)
        val current = getTodaySteps(context)
        val previous = p.getInt(KEY_LAST_STEPS_AT_ACTIVITY_CHECK, -1)
        p.edit().putInt(KEY_LAST_STEPS_AT_ACTIVITY_CHECK, current).apply()
        return previous == current
    }
}
