package com.stepstreak.app

import android.app.Service
import android.content.Context
import android.content.Intent
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder

class StepService : Service(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var stepSensor: Sensor? = null

    override fun onCreate() {
        super.onCreate()
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        stepSensor = sensorManager.getDefaultSensor(Sensor.TYPE_STEP_COUNTER)
        NotificationHelper.ensureChannels(this)
        startForeground(
            NotificationHelper.NOTIF_TRACKING_ID,
            NotificationHelper.buildTrackingNotification(this, StepPrefs.getTodaySteps(this))
        )
        stepSensor?.let { sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI) }
        StepPrefs.checkMissedStreak(this)
        StepWidgetProvider.updateAll(this)
        ReminderScheduler.scheduleNext(this)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        return START_STICKY
    }

    override fun onSensorChanged(event: SensorEvent?) {
        event ?: return
        if (event.sensor.type == Sensor.TYPE_STEP_COUNTER) {
            val total = event.values[0].toInt()
            val result = StepPrefs.onSensorReading(this, total)

            NotificationHelper.updateTrackingNotification(this, result.todaySteps)
            StepWidgetProvider.updateAll(this)
            sendBroadcast(Intent(ACTION_STEPS_UPDATED).setPackage(packageName))

            if (result.goalJustReached) {
                NotificationHelper.showGoalReachedNotification(this, result.todaySteps)
                SoundPlayer.playGoalReached(this)
            }
            result.newlyUnlockedBadge?.let { milestone ->
                NotificationHelper.showBadgeUnlockedNotification(this, milestone)
                SoundPlayer.playBadgeUnlocked(this)
            }
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onDestroy() {
        sensorManager.unregisterListener(this)
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    companion object {
        const val ACTION_STEPS_UPDATED = "com.stepstreak.app.STEPS_UPDATED"

        fun start(context: Context) {
            val intent = Intent(context, StepService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }
    }
}
