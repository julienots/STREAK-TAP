package com.stepstreak.app

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

/** Widget d'écran d'accueil StepStreak : pas du jour, anneau de progression, streak. */
class StepWidgetProvider : AppWidgetProvider() {

    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        appWidgetIds.forEach { id -> updateWidget(context, appWidgetManager, id) }
    }

    companion object {
        /** À appeler depuis le service / l'activité à chaque changement de données. */
        fun updateAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, StepWidgetProvider::class.java))
            ids.forEach { id -> updateWidget(context, manager, id) }
        }

        private fun updateWidget(context: Context, manager: AppWidgetManager, widgetId: Int) {
            val steps = StepPrefs.getTodaySteps(context)
            val goal = StepPrefs.dailyGoal(context)
            val streak = StepPrefs.getStreak(context)
            val progress = if (goal > 0) steps.toFloat() / goal else 0f

            val views = RemoteViews(context.packageName, R.layout.widget_step)
            views.setTextViewText(R.id.tvWidgetSteps, steps.toString())
            views.setTextViewText(R.id.tvWidgetGoal, "/ $goal")
            views.setTextViewText(
                R.id.tvWidgetStreak,
                if (streak > 0) "🔥 $streak" else "🚶 Go !"
            )

            val ringSizePx = (96 * context.resources.displayMetrics.density).toInt()
            val ringBitmap = CircularStepView.renderRingBitmap(context, ringSizePx, progress)
            views.setImageViewBitmap(R.id.ivWidgetRing, ringBitmap)

            val openAppIntent = Intent(context, MainActivity::class.java)
            val pendingIntent = PendingIntent.getActivity(
                context, 0, openAppIntent,
                PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
            )
            views.setOnClickPendingIntent(R.id.widgetRoot, pendingIntent)

            manager.updateAppWidget(widgetId, views)
        }
    }
}
